package com.kh.HomeWork;

public class Homework0126 {

	public static void main(String[] args) {
		
		int age = 10;
		if (age >= 8) {
			System.out.println("학교에 다닙니다.");
		}
		// TODO Auto-generated method stub

	}

}

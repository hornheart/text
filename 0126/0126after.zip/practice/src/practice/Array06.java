package practice;

import java.util.Scanner;

public class Array06 {

	public static void main(String[] args) {
		// 
		
		
		Scanner sc = new Scanner(System.in);
		
		/*
		int size;
		System.out.print("3 이상인 홀수 자연수 입력 : ");
		String str = sc.next();
		*/ //===my
		
		/*
		System.out.print("3 이상인 홀수 자연수 입력 : ");
		int size = sc. nextInt();
		*/ //===my
		
		
		/*
		 * 3 이상인 홀수 자연수 입력받기
		 * 해당크기의 배열 생성
		 * 배열중간 1부터 1씩 증가
		 * 중간이후부터 1씩 감소
		 * 
		 * 입력한 정수가 솔수가 아니거나 3 미만일 경우 "다시 입력"
		 * 다시 정수를 받도록
		 */
		
		System.out.print("정수 : ");
		int num = sc. nextInt();
		
		while(num %2 == 0 || num < 3) {
			System.out.println("다시 입력하세요. ");
			System.out.println("정수 : ");
			num = sc.nextInt();
		}
		
		
		int [] arr = new int [num];
		int mid = num / 2;
		int count = 0;
		
		/*
		arr[0] = 1;
		for (int i = 0; i <= mid; i++) {
			arr[i] = arr[i-1] + 1;
		}	
		
		for (int i = mid + 1; i < arr.length; i++) {
			arr[i] = arr[i-1] - 1;
		}
		*/
		
		for (int i = 0; i < arr.length; i++) {
			if (i <= mid) {
				arr[i] = ++count;
			} else {
				arr[i] = --count;
			}
		}
		
		for (int i = 0; i < arr.length; i++) {
			System.out.print(arr[i] + " ");
		}
	                                                                                               
	 		

	}

}

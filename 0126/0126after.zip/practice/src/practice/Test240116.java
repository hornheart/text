package practice;

public class Test240116 {

	public static void main(String[] args) {
		
		Scanner sc = new scanner (System.in);
		
		// 정수형 변수 num1, num2를 사용자로 부터 입력받아
		// + - * / % 의 결과값을 각각 출력하세요.
		System sc = new Scanner (System.in);
		
		/*
		int num1, num2 ;
		System.out.println(" 첫번째 정수 입력 : ") ;
		num1 = sc.nextInt();
		System.out.println(" 두번째 정수 입력 : ") ;
		num2 = sc.nextInt();
		
		System.out.println(num1 + " + "  + num2 +  " = " + (num1 + num2));
		System.out.println(num1 + " - "  + num2 +  " = " + (num1 + num2));
		System.out.println(num1 + " * "  + num2 +  " = " + (num1 + num2));
		System.out.println(num1 + " / "  + num2 +  " = " + (num1 + num2));
		System.out.println(num1 + " % "  + num2 +  " = " + (num1 + num2));
		System.out.printf("%d %d %d = %d, num1, num2,( num1 % num2 ));
		*/
		
		
		
		// 가위 바위 보를 진행 
		// user1의 가위, 바위, 보 정보와
		// user2의 가위, 바위, 보 정보를 받아 누가 이겼는지를 출력하세요.
		// 가위바위보 정보는 숫자로 입력받습니다. (가위 = 1, 바위 = 2, 보 = 3)
		
		/*
		int num1, num2 ;
		System.out.println("user1 입력 (가위 = 1, 바위 = 2, 보 = 3) : ");
		user1 = sc.nextInt();
		
		System.out.println("user2 입력 (가위 = 1, 바위 = 2, 보 = 3) : ");
		user2 = sc.nextInt();
		
		if (user1 == user2) {
		*/ //=====>반드시 풀어봐야 한다!!!!!
		
		/*
		// 15 ~ 111까지의 수를 순서대로 출력하세요.
		for(int i = 15; i <= 111; i++) {
			System.out.print(i + "");
		}
		*/
		
		// 숫자를 입력받아  * 2인 숫자를 출력하세요.
		// 유저가 숫자 0을 입력할 때까지 반복하세요.
		/*
		int num;
		
		do {
		    System.out.print("숫자 입력 : ");
		    num = sc.nextInt();
		    
		    if (num == 0 ) {
		    	break;
		    
		    }
		    
		    System.out.println( num + " * 2 = ")
		*/
		
		
		// user3의 가위바위보 정보를 입력받고
		// 컴퓨터의 랜덤한 가위바위보 정보를 생성해 
		// 누가 이겼는지를 출력하세요.
		// 가위바위보 정보는 숫자로 입력받습니다. (가위 = 1, 바위 = 2, 보 = 3)
		// 해당 행위를 user3이 5를 입력받을 때까지 반복하세요.
		
		for(int i = 15; i <= 111; )
		
		
		
		
		
		/*
		Scanner sc = new scanner (System.in)
		
		String str;
		System.out.println(" 정수형 변수 입력 : ") ;
		str = sc.next();
		
		int num1, num2 ;
		
		for (int )
		
		System.out.print(" 가위, 바위, 보 ");
		
		*/ //======>계속 틀리는 부분 for
		
		int  random = (int) 
		
		
		
		
		
		
		
		
		
		

	}

}

package practice;

import java.util.Scanner;

public class Loop02 {

	public static void main(String[] args) {
		Scanner sc = new Scanner (System.in);
		
		/*
		System.out.print(" 두 개의 값을 입력 : ");
		String str = sc.next();
		
		for (num1 < i < num2);
				num = sc. nextInt();
				System.out.println();
			*/
		
		
		int num1, num2;
		
		System.out.print("첫 번째 숫자 : ");
		num1 = sc. nextInt();
		
		//num1이 1보다 작다면 다시 입력받기 반복
		
		while(num1 < 1) {
			Sys
		}
		
		
		System.out.print("두 번째 숫자 : ");
		num2 = sc. nextInt();

		min = (num1 < num2 ? )
		
		
		for (int i = (num1 < num2? num1 : num2); i <= (num1 > num2 ? num1 : num2); i++) {
	}

}

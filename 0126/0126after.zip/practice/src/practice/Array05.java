package practice;

import java.util.Scanner;

public class Array05 {

	public static void main(String[] args) {
		// 
		/*
		 * 
		 * 사용자가 배열의 길이 입력
		 * 그 값만큼 정수현 배열 선언 및 할당
		 * 배열의 크기만큼 사용자가 값을 입력
		 * 각각의 인덱스에 값을 초기화
		 * 
		 * 배열  전체 값 나열
		 * 각 인덱스에 저장된 합을 출력
		 */
		
		
		//1. 배열의 크기만큼 사용자가 직접 값을 입력하여 가각의 인덱스에 값을 초기화 배열의 길이 직접 입력
		//2. 배열의 크기만큼
		
		
		Scanner sc = new Scanner(System.in);
		/*
		int size;
		
		System.out.print(" 정수 입력 : ");
		size = sc.nextInt();
		*/
		
		/*
		String [] num = {"4", "-4", "3", "-3", "2"}
		
		int num;
		
		do {
			System.out.print( "숫자 입력 (0~6) : ");
			num = sc.nextInt();
		} while ((num >= 0 && num <=5));
		
		System.out.println([num] + " ");
		  */
		
		System.out.print( "숫자 입력 (0~6) : ");
		int size = sc.nextInt(); // 임의 값을 설정 *3~5사이가 적정*
		
		int[] arr = new int[size]; // 크기가 3인 정수현 배열 arr생성
		for (int i = 0; i < arr.length; i++) { // 0 ~ 배열의 끝까지
			for (int i = 0; i < arr.length; i++) {
			arr[i] = sc.nextInt();
		}
		
		for (int i = 0; i < arr.length; i++) {
			for (int i = 0; i < arr.length; i++) {arr[i] + " ");
			sum += arr[i];
		}
		
		

	}

}

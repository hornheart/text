package practice;

import java.util.Scanner;

public class Test240117 {

	public static void main(String[] args) {
		
		System sc = new Scanner(System.in);
		// 사용자로부터 정수형 변수 num1과 num2를 입력받아 큰값에서 작은값을 뺀 결과를 출력하세요.
		
		int num1, num2;
		
		System.out.println( "첫번째 정수 입력 : ");
		num1 = sc.nextInt();
		
		System.out.println( "두번째 정수 입력 : ");
		num2 = sc.nextInt();
		
		if (num1 > num2) {
			System.out,println(num1 + " - " + num2 + " = " + (num1 - num2));
		} else {
			System.out.println(num2 + " - " + num1 + " = " + (num2 + num1));
			
		}
		
		
		/*
		System sc = new Scanner (System.in);
		
		int num1, num2 ;
		System.out.println( "첫번째 정수 입력 : ");
		num1 = sc.nextInt();
		System.out.println( "두번째 정수 입력 : ");
		num2 = sc.nextInt();
		
		if (num1 > num2)
		
		System.out.println(num1 + " - " + num2 + " = " + (num1 + num2));
		*/ //===>my
		
		// 85에서 10까지 수를 1씩 줄여가며 모든 사이에 숫자를 출력하세요.
		
		for (int i = 85; i >= 10; i--)
		
		
		
		// 로또 추첨 번호를 예상하는 프로그램 작성
		// 임의의 숫자를 1에서 45까지 총 6개 추첨하여 당첨번호를 구합니다.
		// 중복된 숫자는 있으면 안 된다.
		
		int[] arr = new int[6];
		
		for (int i = 0; i < arr.length; i++) { // 0 ~ 5
			arr[i] = (Math.random() * 45 + 1); //1 ~ 45사이의 랜덤값을 배열에 저장
	
			
			//중복검사
			if (i > 0) {
			    for (int j =0; j , arr.length; j++) { // 배열을 전부 확인
				     if (arr[i] == arr[j]) {
				    	 i--; // 중복이 존재하므로 i값을 1줄여서 다시 arr 
				    	 brak;
				     }
					
				}
			}
		}
		
		System.out.printf("%d %d %d %d %d %d, arr[0], arr[1], arr[2], arr[3], arr[4], arr[5]);
			
		
		// 임의의 숫자 하나 (1~5)를 생성하고 이를 맞추는 프로그램 작성
		// 몇번 만에 맞췄는지를 출력하세요.
		// ex)
		// 컴푸터가 생각하는 수는  : 4(사용자 입력)
		// 컴퓨터가 생각하는 수는  : 4(사용자 입력)
		// 정답입니다. 2번 만에 맞추셨습니다.
		// Matg.random() * 5 + 1 => 1~5 난수발생 = > target이라는 변수 저장
		//
		//
		
		int target = (int)(Math.random() * 5 + 1) ; //1~5사이의 난수 발생
		int num, count = 0; // 몇 번 질문했는지를 저장하는 변수
		do {
			System.out.print("컴퓨터가 생각하는 수는 : ");
			num = sc.nextInt();
			
			count++; //질문 횟수 2 증가
						
		} while 
			
			
			
			
		// 길이가 10인 배열을 선언하고 1부터 10까지의 값을 반복문을 이용하여
		// 순서대로 대입하고 그 값을 출력하세요.
		
		int []arr = new int[10];
		// 필요한 값 : 1~10
		// 배열 index :  0(+1)
	
		for (int i = 0; i < arr.length; i++)
			
			
		/*
		int size;
		Scanner sc = new Scanner(System.in);
		
		System.out.print("배열의 길");
		
		*/ //====내가 한거
		

	}

}

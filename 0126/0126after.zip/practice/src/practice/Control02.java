package practice;

import java.util.Scanner;
public class Control02 {
	public static void main(String[] args) {
		// 실수형으로 국,영,수 총점 평균
		//합격인지 불합격인지
		//합격조건 :  세과목 점수 40이상 평균 60점



	Scanner sc = new Scanner(System.in);
	double ko, ma, en;
	int total;
	
	System.out.println("국어 :");
	ko = sc.nextDouble();
	
	System.out.println("수학 : ");
	ma = sc.nextDouble();
	
	System.out.println("영어 : ");
	en = sc.nextDouble();
	
	System.out.println("총점 : " + (int)(ko + ma + en));
	System.out.println("평균 : " + (int)((ko + ma + en) / 3));
	
	//========
	//내가
	//if ((int)((ko + ma + en) / 3) > 60)
	//	System.out.println("축하합니다. 합격입니다.");
	//========
	
	total = (int)(ko + ma + en);
	
	if (ko >= 40 && ma >= 40 && en >= 40 && evg >=60 ) {
		System.out.println("국어 : " + ko);
		System.out.println("수학 : " + ma);
		System.out.println("영어 : " + en);
		System.out.println("합계 : " + total);
		System.out.println("평균 : " + evg);
		System.out.println("축하합니다, 합격입니다.!");
	} else {
		System.out.println("불합격입니다.");
		
	}
  }
}
	
	
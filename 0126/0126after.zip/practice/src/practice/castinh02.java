package practice;

import java.util.Scanner;
public class castinh02 {
	public static void main(String[] args) {
		
		//실수형으로 국,영,수 총점 평균
		// 정수형
		
		/*
		 * 국 : 90.0
		 * 수 : 90.0
		 * 영 : 90.0
		 * 
		 * 총 : 270
		 * 평 :90
		
		 */
		
		
		
		
	//내가한거	
		
//		Scanner sc = new Scanner(System.in);
//		
//		int num;
//		
///		System.out.print("과목 점수 입력 : ");
		
//		num = sc. nextInt();
//		
	
		Scanner sc = new Scanner(System.in);
		double ko, ma, en;
		
		System.out.println("국어 :");
		ko = sc.nextDouble();
		
		System.out.println("수학 : ");
		ma = sc.nextDouble();
		
		System.out.println("영어 : ");
		en = sc.nextDouble();
		
		System.out.println("총점 : " + (int)(ko + ma + en));
		System.out.println("평균 : " + (int)((ko + ma + en) / 3));
		
		
		
		
		
		
		
	}

}

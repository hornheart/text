package practice;

import java.util.Scanner;

public class ControllAndLoop02 {

	public static void main(String[] args) {
		//
		
		Scanner sc = new Scanner(System.in);
		
		
		/*
		String name;
		
		int num1, com;
		System.out.print("user1 입력 (가위 = 1, 바위 = 2, 보 = 3) : ");
		str = sc.nextInt();
		random = (int) 
		System.out.print(random);
		str = sc.nextInt();
			*/ //====>my
		
		
		int win = 0, draw = 0, lose = 0;
		String name, userChoice, comChoice;
		System.out.print("당신의 이름을 입력해주세요 : ");
		name = sc.next();
		String[] arr = {"가위", "바위", "보"};   // 수월
		
		
		System.out.print("가위, 바위, 보 : ");
		useChoice = sc.next();
		
		comChoice = arr[(int) (Math.random() *3)]; //컴퓨터의 선책 받기
		
		System.out.println("컴퓨터 :  " + comChoice);
		System.out.println(name + " : " + userChoice);
		
		if (userChoice.equals(comChoice)) { //컴퓨터가 이긴 경우
			System.out.println("비겼습니다. ");
			draw++;
		} else if ( (userChoice.equals("가위") && comChoice.equals("보")) ||
				(userChoice.equals("바위") && comChoice.equals("가위")) ||
				(userChoice.equals("보") && comChoice.equals("바위")) ) { //유저가 이긴 경우
			win++;
			System.out.println("이겼습니다.!! ");
			
		} else {
			lose++;
			System.out.println("졌습니다. ㅜㅜ ");
		}
		System.out.println();
		
		
				
		

	}

}

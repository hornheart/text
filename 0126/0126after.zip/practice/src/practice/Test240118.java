package practice;

import java.util.Scanner;

public class Test240118 {

	public static void main(String[] args) {
		Scanner sc = new scanner (System.in);
		
		// 실수 num1과 num2를 사용자로부터 입력받아 + % / 3가지의 결과를 출력해라
		
		/*
		int num1, num2;
		 
		System.out.print();
		*/ //==my
		double num1, num2;
		System.out.print(" 첫번째 실수 입력 : ") ;
		num1 = sc.nextDouble();
		System.out.println(" 두번째 실수 입력 : ") ;
		num2 = sc.nextDouble();
           		
		System.out.println(num1 + " / "  + num2 +  " = " + (num1 + num2));
		System.out.println(num1 + " % "  + num2 +  " = " + (num1 + num2));
		System.out.println(num1 + " + "  + num2 +  " = " + (num1 + num2));
		
		// 정수형 변수 num3를 사용자로부터 입력받아 100보다 작으면 100이하
		// 200보다 크고 300보다 작으면 300이하를 출력하고
		int num3
		 
		System.out.println("정수 입력 : ");
		num3 = sc.nextInt();
		
		/*
		if (100 < i )
			*/ //====my
		
		
		/*
		if (num 3 < 100) {
			System.out.println("100이하 ");
					
		} else if(num < 200 ) {
			System.out.println("200이하");
		} else if(num < 300) {
			System.out.println("300이하");
		} else {
			System.out.println("300초과");
		}
			*/
		
		
		// 그것도 아니면 300초과를 출력해라
		/*
		double num1, num2;
		
		System.out.println(" 첫번째 실수 입력 : ") ;
		num1 = sc.next...(); //더블
		System.out.println(" 두번째 실수 입력 : ") ;
		num2 = sc.nextInt();
		
		System.out.println(num1 + " + "  + num2 +  " = " + (num1 + num2));
		
		System.out.println(num1 + " / "  + num2 +  " = " + (num1 + num2));
		System.out.println(num1 + " % "  + num2 +  " = " + (num1 + num2));
		System.out.printf("%d %d %d = %d, num1, num2,( num1 % num2 )); //틀린거
		*/ //===my
		
		
				
				
		// 수학, 영어, 국어 성적을 입력받아 평균이 60이상이면 합격입니다.
		// 60보다 작으면 불합격입니다. 출력
				
		
		/*double ko, ma, en;
				
				en = sc.nextDouble();
				ko = sc.nextDouble();
				
				System.out.println("수학 : ");
				ma = sc.nextDouble();
				
				System.out.println("영어 : ");
				en = sc.nextDouble();
				
				System.out.println("총점 : " + (int)(ko + ma + en));
				System.out.println("평균 : " + (int)((ko + ma + en) / 3));
				
				*/ //===my
		
		/*
		int ko, ma, en;
		
		System.out.println("국어, 수학, 영어 점수를 입력해 주세요");
		ma = sc.nextInt();
		en = sc.nextInt();
		ko = sc.nextInt();
		
		if ((ma + en + ko) / 3 >= 60) {
			System.out.println("합격입니다. ");
		} else {
			System.out.println("불합격입니다. ");
		}
		
				*/
		
		// 국어성적을 입력받아 50점 이하는 f학점 50점 초과 60점 이하는 d학점
		// 60점 초과 70점 이하는 c학점
		// 70점 초과 80점 이하는 b학점
		// 80점 초과는 a학점 출력하는 프로그램을 작성해라.
		
		/*
		int ko;
		
		System.out.print("국어 성적을 입력해주세요 : ");
		ko = sc.nextInt();
		if (ko <= 50) {
			System.out.print("f");
		} else if( ko <= 60) {
			System.out.print("d");
			
		} else if ( ko <=70) {
			System.out.println("c");
		} else if (ko<=80) {
			System.out.println("b");
		} else {
			System.out.println("a");
		}
		      
		
	*/
		
		
		
		// 크기가 9인 1차원 배열 arr1을 작성하고 구구단 2단을 각 인덱스에 대입해라
		// ex) arr1[0] = "2 * 1 = 2";
		String[] arr1 = new String[9];
		for (int i = 0; i < arr1.length; i++) { //0 1 2 3 4 5 6 7 8
			int su = i + 1
			arr[i] = "2 * " + su + " = " + (2 * su); // int su = i + 1
		}	
		
		*/
		// 크기가 9인 1차원 배열 arr2을 작성하고 구구단 2단을 각 인덱스에 대입해라
		// ex) arr2[0] = "3 * 1 = 3";
		/*
		String[] arr2 = new String[9];
		for (int i = 0; i < arr2.length; i++) {
			int su = i + 1;
			arr2[i] = "3  * " + su + " = " + (3 * su);
		}
		
		for (int i = 0; i < arr2.length; i++) {
			System.out.println(arr2[i]);
		}
		*/
		
		
		// 크기가 [8][9]인 2차원 배열 arr3을 작성하고 구구단 2~9단을 각 인덱스에 대입하고 출력해라
		// ex) arr3[0][0] = "2 * 1 = 2";
		/*
		String[][] arr3 = new String[8][9]
				
				
		for (int j = 0; j < arr3.length; j++) { // 0 1 2 3 4 5 6 7
			for (int i = 0; i < arr3[j].length; i++) { // 0 1 2 3 4 5 6 7 8
				int dan = j + 2;
				int su = i + 1;
				
				arr3[j][i] = dan + " * " + su + " = " + (dan * su);
			}
		}
			//구구단의 한 단을 배열에저장하는 반복문
		for (int i = 0; i < arr3.length; i++) {
			System.out.println("===" + (i +2) + "단====");
		}
			for (int j = 0; j < arr3[i]).length; j++) {
				
				System.out.println(arr3[i][j]);
			}
		}
			
		*/
		
		

	}

}

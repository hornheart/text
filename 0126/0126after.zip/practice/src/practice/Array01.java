package practice;
import java.util.Scanner;
public class Array01 {

	public static void main(String[] args) {
		
		
		// 사용자에게 입력받은 양의 정수만큼 배열의 크기를 할당하고
		// 1부터 입력받은 값까지 배열에 초기화한 후 출력하세요.
		
		Scanner sc = new Scanner(System.in);
		
		/*
		int num;
		
		
		System.out.println( " 정수 입력 : ");
		num = sc.nextInt();
		
		int [num] arr = new int[num];
		
		for (int i = 0; i < arr.length; i++)
		*/ //===>my
		
		
		int size; // 1. size 변수 선언
		
		System.out.print(" 정수 입력 : ");
		size = sc.nextInt(); //2. size에 사용자로부터 받은 값 대입 (일단 5라 생각)
		
		int [] arr = new int[size]]; //3.사용자로부터 받은 값 만큼의 크기 배열 생성 (일단 크기는 5인 배열)
		for (int i = 0; i < arr.length; i++) { // 4. 배열전체 탐색 (index 0~4)
			arr[i] = i + 1; // 5. 0-> arr[0] = 0 + 1;
			                //        arr[1] = 1 + 1;
			                //        arr[2] = 2 + 1; 
		}
		
		for (int i = 0; i < arr.length; i++) {
			System.out.print(arr[i] + " ");
		
		
		

	}

}

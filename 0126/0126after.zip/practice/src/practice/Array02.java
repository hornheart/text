package practice;

public class Array02 {

	public static void main(String[] args) {
		
		// 길이가 5인 String배열을 선언하고 사과, 귤, 포도, 복숭아, 참외로 초기화합니다.
		// 이후 인덱스를 이용해서 귤을 출력하세요.
		
		
		/*
		int []arr = new int[5];
		
		for (int i = 0; i < arr.length; i++)
			arr[i] = 1;
		
		for (int i )
			*/
		
		
		String[] arr = {"사과", "귤", "포도", "복숭아", "참외"};
		System.out.print(false);
		
		

	}

}

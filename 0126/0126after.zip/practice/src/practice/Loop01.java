package practice;

import java.util.Scanner;

public class Loop01 {

	public static void main(String[] args) {
		// 1이상 변수 num을 입력받고
		// 1부터 num의 숫자를 
		
		
		/*
		Scanner sc = new scanner ( System.in);
		
			
		
		System.out.print("1이상의 숫자를 입력하세요 : ");
		size = sc.next();
		
		for (int i = 0; i =< 4 ; i++) {
			arr[i] = (int)(Math.random() * i +1);
		}
		*/ //====my
		
		
		/*
		Scanner sc = new scanner ( System.in);
		int num;
		
		System.out.print("1이상의 숫자를 입력하세요 : ");
		num = sc.nextInt();
		
		if (num > 0 ) {
			for (int i = 1; i <=num; i++) {
				System.out.print(i + " ");
			}
			
		} else {
			System.out.println("1 이상의 숫자를 입력하세요");
		}
		
		*/
		
		//1미만의 숫자를 입력받았을 때
		//1이상의 숫자를 입력
		//정상적으로 입력할 때까지
		Scanner sc = new scanner ( System.in);
		int num;
		
		System.out.print("1이상의 숫자를 입력하세요 : ");
		num = sc.nextInt();
		
		
		
		while (num < 1) { //1보다 작은 수를 입력했을 때 반복
			System.out.println("1 이상의 숫자를 입력하세요");
			num = sc.nextInt();
			
		}
		//num은 1보다 큰 값이 들어있을 것이다.
		for (int i = 1; i <= num; i++) { //i는 1부터 i는 num보다 커질 때까지 1씩 증가 출력
			System.out.print(i + " ");
		}
		
		
		

	}

}

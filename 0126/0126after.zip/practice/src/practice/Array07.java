package practice;

import java.util.Scanner;


public class Array07 {

	public static void main(String[] args) {
		//
		
		
		
		
		/*
		 * 사용자가 입력한 값이 배열에 있는지 검색
		 * "000치킨 배달 가능"
		 * 없으면 "000치킨은 없는 메뉴입니다."
		 * 치킨 메뉴가 들어가있는 배열은 본인이 정하시오
		 */
		Scanner sc = new Scanner(System.in);
		
		/*
		
		int size;
		*/ //===my
		
		boolean isTure = false; //3.
		
		String[] menu = {"후라이드", "양념", "간장"}; //1.치킨종류 메뉴배열 생성
		
		System.out.print("치킨 이름을 입력하세요 : ");
		String pick = sc.next(); //2. 사용자로 부터 치킨입력 받음 => 예: 양념
		
		for (int i =0; i < menu.length; i++) {
			if (menu[i].equals(pick)) {
				isTrue = true;
				break;
			}
		}
		
		if (isTrue) {
			System.out.println(pick + "치킨 배달 가능");
		} else {
			System.out.println(pick + "치킨은 없는 메뉴입니다.");
		}
		
				

	}

}

package com.kh.Test240123;

public class Student {
	
	
	private String name;
	private int math;
	private int korean;
	private int english;
	@Override
	public String toString() {
		return "Student [name=" + name + ", math=" + math + ", korean=" + korean + ", english=" + english + "]";
		
	}
	
	
	
	
}
	/*////=my
	public static void main (String[] args) {

		int ma, ko, en;
		 System.out.print(" 이름 수학/국어/영어 점수를 입력해 주세요");
		
		 ma = sc.nextInt();
		 ko = sc.nextInt();
		 en = sc.nextInt();
		 
		 int evg = (this. )
	*/

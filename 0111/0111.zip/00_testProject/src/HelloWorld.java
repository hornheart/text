
public class HelloWorld {
	public static void main(String[] args){
      System.out.println(300);
      //정수 및 수 표현
      /*
       * 인사
       * 기타등등
       */
      
      System.out.println("hello");
      System.out.println(30+24+36);
   }
}




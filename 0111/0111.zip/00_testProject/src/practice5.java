import java.util.Scanner;
public class practice5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		
		Scanner scan = new Scanner(System.in );
		
		System.out.print("이름을 입력하세요 : ");
		String.name = scan.next();
		System.out.print("성별을 입력하세요 : ");
		char gender = scan.next().charAt(0);
		System.out.print("나이를 입력하세요 : ");
		int age = scan.nextInt();
		scan.nextLine();
		
		
		
		
		
		
		/*
		 * 인사하기
		 */
		
		
		

	}

}
